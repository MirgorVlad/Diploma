def print_text_from_feature(text:str):
	print(text)
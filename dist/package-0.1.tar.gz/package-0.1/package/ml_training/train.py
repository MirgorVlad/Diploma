def print_text_from_training(text:str):
	print(text)